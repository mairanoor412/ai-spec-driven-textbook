
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/ai-spec-driven-textbook/',
    component: ComponentCreator('/ai-spec-driven-textbook/','6cb'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug','729'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug/config',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug/config','39b'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug/content',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug/content','636'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug/globalData',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug/globalData','bc2'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug/metadata',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug/metadata','90a'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug/registry',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug/registry','2a0'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/__docusaurus/debug/routes',
    component: ComponentCreator('/ai-spec-driven-textbook/__docusaurus/debug/routes','c23'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog',
    component: ComponentCreator('/ai-spec-driven-textbook/blog','023'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/archive',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/archive','c92'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/first-blog-post',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/first-blog-post','df9'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/long-blog-post',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/long-blog-post','c44'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/mdx-blog-post',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/mdx-blog-post','dd0'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/tags',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/tags','c1c'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/tags/docusaurus',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/tags/docusaurus','0b5'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/tags/facebook',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/tags/facebook','110'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/tags/hello',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/tags/hello','af6'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/tags/hola',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/tags/hola','15b'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/blog/welcome',
    component: ComponentCreator('/ai-spec-driven-textbook/blog/welcome','d12'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags','f85'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/accessibility',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/accessibility','a62'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/advanced-robotics',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/advanced-robotics','301'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/ai',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/ai','199'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/ai-fundamentals',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/ai-fundamentals','8f2'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/ai-integration',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/ai-integration','a6a'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/ai-workflows',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/ai-workflows','89d'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/alt-text',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/alt-text','11a'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/applications',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/applications','fd7'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/autonomous-systems',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/autonomous-systems','523'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/biomechanics',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/biomechanics','52f'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/code-examples',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/code-examples','8ad'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/computer-vision',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/computer-vision','ef3'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/control-systems',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/control-systems','f41'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/cpp',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/cpp','ceb'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/cutting-edge',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/cutting-edge','ad0'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/design-principles',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/design-principles','0c3'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/difficulty',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/difficulty','c66'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/embodied-cognition',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/embodied-cognition','9ea'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/examples',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/examples','0fe'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/exercises',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/exercises','3ff'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/glossary',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/glossary','89c'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/humanoid',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/humanoid','f13'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/humanoid-robotics',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/humanoid-robotics','90e'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/inclusive-design',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/inclusive-design','243'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/index',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/index','d65'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/industrial-robots',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/industrial-robots','ed1'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/kinematics',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/kinematics','7d9'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/learning-guide',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/learning-guide','805'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/learning-levels',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/learning-levels','b52'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/learning-styles',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/learning-styles','2c1'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/machine-learning',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/machine-learning','de0'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/navigation',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/navigation','43c'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/path-planning',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/path-planning','d16'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/perception',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/perception','7fa'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/physical-ai',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/physical-ai','82f'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/practical-skills',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/practical-skills','c6e'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/prerequisites',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/prerequisites','3a6'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/python',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/python','c47'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/pytorch',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/pytorch','cc0'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/real-world',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/real-world','a4f'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/reference',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/reference','b51'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robot-control',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robot-control','968'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robotics',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robotics','c4c'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robotics-applications',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robotics-applications','a87'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robotics-development',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robotics-development','5b9'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robotics-programming',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robotics-programming','c26'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robotics-research',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robotics-research','42c'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/robotics-tools',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/robotics-tools','ce8'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/ros-2',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/ros-2','1b4'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/safety',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/safety','332'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/screen-readers',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/screen-readers','627'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/search',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/search','f34'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/sensor-integration',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/sensor-integration','bc3'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/sensors',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/sensors','c10'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/service-robots',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/service-robots','628'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/simulation',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/simulation','365'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/specialized-applications',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/specialized-applications','fb4'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/tensorflow',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/tensorflow','9ea'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs/tags/vla',
    component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/vla','cea'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/markdown-page',
    component: ComponentCreator('/ai-spec-driven-textbook/markdown-page','29b'),
    exact: true
  },
  {
    path: '/ai-spec-driven-textbook/docs',
    component: ComponentCreator('/ai-spec-driven-textbook/docs','25f'),
    routes: [
      {
        path: '/ai-spec-driven-textbook/docs/tags/tags',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/tags/tags','ee9'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/chapter-concepts-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/chapter-concepts-template','a0e'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/chapter-examples-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/chapter-examples-template','4e1'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/chapter-exercises-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/chapter-exercises-template','6f9'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/chapter-index-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/chapter-index-template','2ea'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/chapter-state-management',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/chapter-state-management','0f1'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/chapter-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/chapter-template','517'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/content-review-workflow',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/content-review-workflow','3c5'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/content-verification-process',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/content-verification-process','755'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/exercises-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/exercises-template','c75'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/image-diagram-guidelines',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/image-diagram-guidelines','bff'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/learning-outcomes-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/learning-outcomes-template','c1f'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/templates/module-structure',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/templates/module-structure','791'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/accessibility-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/accessibility-guide','692'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/bookmarks',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/bookmarks','11e'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/concepts/concepts',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/concepts/concepts','eb0'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/examples/examples',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/examples/examples','f04'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/exercises/exercises',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/exercises/exercises','b23'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/index/index',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/index/index','a6b'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/review-request',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/review-request','50a'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/revision-log',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/revision-log','62f'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-01/spec',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-01/spec','f73'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-02/concepts/concepts',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-02/concepts/concepts','02a'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-02/examples/examples',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-02/examples/examples','438'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-02/exercises/exercises',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-02/exercises/exercises','456'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-02/index/index',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-02/index/index','488'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-02/spec',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-02/spec','467'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-03-practical-robotics-skills',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-03-practical-robotics-skills','889'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-03/code/code',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-03/code/code','17c'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-03/concepts/concepts',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-03/concepts/concepts','a74'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-03/examples/examples',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-03/examples/examples','e0f'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-03/exercises/exercises',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-03/exercises/exercises','dbe'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-03/index/index',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-03/index/index','025'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-04-robotics-ethics-safety',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-04-robotics-ethics-safety','c02'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-04/code/code',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-04/code/code','1a3'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-04/concepts/concepts',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-04/concepts/concepts','160'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-04/examples/examples',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-04/examples/examples','916'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-04/exercises/exercises',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-04/exercises/exercises','ffc'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-04/index/index',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-04/index/index','d3e'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-05-advanced-robotics-applications',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-05-advanced-robotics-applications','959'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-05/concepts/concepts',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-05/concepts/concepts','552'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-05/examples/examples',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-05/examples/examples','7a0'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-05/exercises/exercises',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-05/exercises/exercises','eb6'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/chapter-05/index/index',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/chapter-05/index/index','a16'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/difficulty-badges',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/difficulty-badges','3e0'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/assessment-tools-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/assessment-tools-template','878'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/case-studies-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/case-studies-template','f19'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/exercises-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/exercises-template','b37'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/feedback-system-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/feedback-system-template','c93'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/hands-on-projects-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/hands-on-projects-template','5e8'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/integration-example',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/integration-example','5e0'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/interactive-elements-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/interactive-elements-template','c31'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/real-world-examples-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/real-world-examples-template','188'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/examples/solutions-feedback-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/examples/solutions-feedback-template','73b'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/glossary',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/glossary','4de'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/index',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/index','b0e'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/index-reference',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/index-reference','aa7'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/learning-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/learning-guide','b79'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/practice/application-exercises',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/practice/application-exercises','b79'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/practice/collaboration-tools',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/practice/collaboration-tools','3c4'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/practice/hands-on-projects',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/practice/hands-on-projects','b48'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/practice/project-based-learning',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/practice/project-based-learning','fa5'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/practice/simulation-environments',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/practice/simulation-environments','b76'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/practice/validation-tools-checklists',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/practice/validation-tools-checklists','212'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/toc',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/toc','c99'),
        exact: true,
        'sidebar': "textbookSidebar"
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/accessibility-features',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/accessibility-features','dd7'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/accessibility-features-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/accessibility-features-guide','bff'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/alternative-text-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/alternative-text-guide','8ac'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/captions-references-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/captions-references-guide','584'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/design-standards',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/design-standards','027'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/image-optimization-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/image-optimization-guide','d78'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/interactive-diagrams-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/interactive-diagrams-template','db8'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/mdx-integration-examples',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/mdx-integration-examples','247'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/mdx-integration-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/mdx-integration-guide','a48'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/placeholder-diagrams',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/placeholder-diagrams','7ac'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/textbook/visuals/responsive-images-guide',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/textbook/visuals/responsive-images-guide','91e'),
        exact: true
      },
      {
        path: '/ai-spec-driven-textbook/docs/ux-testing/ux-testing-report-template',
        component: ComponentCreator('/ai-spec-driven-textbook/docs/ux-testing/ux-testing-report-template','737'),
        exact: true
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*')
  }
];
