export default {
  "title": "AI/Spec-Driven Textbook for Physical AI & Humanoid Robotics",
  "tagline": "Learn Physical AI and Humanoid Robotics through Spec-Driven Development",
  "url": "https://mairanoor412.github.io",
  "baseUrl": "/ai-spec-driven-textbook/",
  "onBrokenLinks": "warn",
  "onBrokenMarkdownLinks": "warn",
  "favicon": "img/favicon.ico",
  "organizationName": "mairanoor412",
  "projectName": "ai-spec-driven-textbook",
  "presets": [
    [
      "@docusaurus/preset-classic",
      {
        "docs": {
          "sidebarPath": "C:\\Users\\asfar\\quarter-4\\hackathon-1\\humanoid-robotics\\textbook\\sidebars.js",
          "routeBasePath": "/docs",
          "sidebarCollapsible": true,
          "showLastUpdateAuthor": false,
          "showLastUpdateTime": false,
          "remarkPlugins": [],
          "editUrl": "https://github.com/your-organization/humanoid-robotics/edit/main/textbook/"
        },
        "blog": {
          "showReadingTime": true,
          "editUrl": "https://github.com/facebook/docusaurus/edit/main/website/blog/"
        },
        "theme": {
          "customCss": "C:\\Users\\asfar\\quarter-4\\hackathon-1\\humanoid-robotics\\textbook\\src\\css\\custom.css"
        }
      }
    ]
  ],
  "themes": [],
  "plugins": [],
  "themeConfig": {
    "navbar": {
      "title": "Physical AI & Humanoid Robotics",
      "logo": {
        "alt": "Humanoid Robotics Textbook Logo",
        "src": "img/logo.svg"
      },
      "items": [
        {
          "type": "doc",
          "docId": "textbook/index",
          "position": "left",
          "label": "Textbook"
        },
        {
          "type": "doc",
          "docId": "textbook/toc",
          "position": "left",
          "label": "Chapters"
        },
        {
          "href": "https://github.com/your-organization/humanoid-robotics",
          "label": "GitHub",
          "position": "right"
        }
      ],
      "hideOnScroll": false
    },
    "footer": {
      "style": "dark",
      "links": [
        {
          "title": "Textbook",
          "items": [
            {
              "label": "Get Started",
              "to": "/docs/textbook"
            },
            {
              "label": "Chapter 1: Physical AI Fundamentals",
              "to": "/docs/textbook/chapter-01/index/"
            },
            {
              "label": "All Chapters",
              "to": "/docs/textbook/toc"
            }
          ]
        },
        {
          "title": "Resources",
          "items": [
            {
              "label": "Spec-Kit Plus",
              "href": "https://github.com/spec-driven/spec-kit-plus"
            },
            {
              "label": "Docusaurus",
              "href": "https://docusaurus.io"
            },
            {
              "label": "Robotics Learning",
              "href": "https://www.ros.org"
            }
          ]
        },
        {
          "title": "More",
          "items": [
            {
              "label": "GitHub",
              "href": "https://github.com/your-organization/humanoid-robotics"
            }
          ]
        }
      ],
      "copyright": "Copyright © 2025 AI/Spec-Driven Textbook for Physical AI & Humanoid Robotics. Built with Docusaurus."
    },
    "prism": {
      "theme": {
        "plain": {
          "color": "#393A34",
          "backgroundColor": "#f6f8fa"
        },
        "styles": [
          {
            "types": [
              "comment",
              "prolog",
              "doctype",
              "cdata"
            ],
            "style": {
              "color": "#999988",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "namespace"
            ],
            "style": {
              "opacity": 0.7
            }
          },
          {
            "types": [
              "string",
              "attr-value"
            ],
            "style": {
              "color": "#e3116c"
            }
          },
          {
            "types": [
              "punctuation",
              "operator"
            ],
            "style": {
              "color": "#393A34"
            }
          },
          {
            "types": [
              "entity",
              "url",
              "symbol",
              "number",
              "boolean",
              "variable",
              "constant",
              "property",
              "regex",
              "inserted"
            ],
            "style": {
              "color": "#36acaa"
            }
          },
          {
            "types": [
              "atrule",
              "keyword",
              "attr-name",
              "selector"
            ],
            "style": {
              "color": "#00a4db"
            }
          },
          {
            "types": [
              "function",
              "deleted",
              "tag"
            ],
            "style": {
              "color": "#d73a49"
            }
          },
          {
            "types": [
              "function-variable"
            ],
            "style": {
              "color": "#6f42c1"
            }
          },
          {
            "types": [
              "tag",
              "selector",
              "keyword"
            ],
            "style": {
              "color": "#00009f"
            }
          }
        ]
      },
      "darkTheme": {
        "plain": {
          "color": "#F8F8F2",
          "backgroundColor": "#282A36"
        },
        "styles": [
          {
            "types": [
              "prolog",
              "constant",
              "builtin"
            ],
            "style": {
              "color": "rgb(189, 147, 249)"
            }
          },
          {
            "types": [
              "inserted",
              "function"
            ],
            "style": {
              "color": "rgb(80, 250, 123)"
            }
          },
          {
            "types": [
              "deleted"
            ],
            "style": {
              "color": "rgb(255, 85, 85)"
            }
          },
          {
            "types": [
              "changed"
            ],
            "style": {
              "color": "rgb(255, 184, 108)"
            }
          },
          {
            "types": [
              "punctuation",
              "symbol"
            ],
            "style": {
              "color": "rgb(248, 248, 242)"
            }
          },
          {
            "types": [
              "string",
              "char",
              "tag",
              "selector"
            ],
            "style": {
              "color": "rgb(255, 121, 198)"
            }
          },
          {
            "types": [
              "keyword",
              "variable"
            ],
            "style": {
              "color": "rgb(189, 147, 249)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "comment"
            ],
            "style": {
              "color": "rgb(98, 114, 164)"
            }
          },
          {
            "types": [
              "attr-name"
            ],
            "style": {
              "color": "rgb(241, 250, 140)"
            }
          }
        ]
      },
      "additionalLanguages": []
    },
    "colorMode": {
      "defaultMode": "light",
      "disableSwitch": false,
      "respectPrefersColorScheme": false,
      "switchConfig": {
        "darkIcon": "🌜",
        "darkIconStyle": {},
        "lightIcon": "🌞",
        "lightIconStyle": {}
      }
    },
    "docs": {
      "versionPersistence": "localStorage"
    },
    "metadatas": [],
    "hideableSidebar": false
  },
  "baseUrlIssueBanner": true,
  "i18n": {
    "defaultLocale": "en",
    "locales": [
      "en"
    ],
    "localeConfigs": {}
  },
  "onDuplicateRoutes": "warn",
  "customFields": {},
  "titleDelimiter": "|",
  "noIndex": false
};