export default [
  require("C:\\Users\\asfar\\quarter-4\\hackathon-1\\humanoid-robotics\\textbook\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\asfar\\quarter-4\\hackathon-1\\humanoid-robotics\\textbook\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\asfar\\quarter-4\\hackathon-1\\humanoid-robotics\\textbook\\node_modules\\@docusaurus\\theme-classic\\lib\\admonitions.css"),
  require("C:\\Users\\asfar\\quarter-4\\hackathon-1\\humanoid-robotics\\textbook\\src\\css\\custom.css"),
];
